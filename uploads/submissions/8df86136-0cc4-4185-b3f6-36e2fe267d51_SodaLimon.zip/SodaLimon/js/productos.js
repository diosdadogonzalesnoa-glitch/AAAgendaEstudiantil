document.addEventListener("DOMContentLoaded", () => {
    // --- ELEMENTOS DEL DOM ---
    const openCartBtn = document.getElementById('open-cart-btn');
    const closeCartBtn = document.getElementById('close-cart-btn');
    const cartPanel = document.getElementById('cart-panel');
    const cartOverlay = document.getElementById('cart-overlay');
    const cartBody = document.getElementById('cart-body');
    const cartTotalSpan = document.getElementById('cart-total');
    const cartBadge = document.getElementById('cart-badge');
    const cartEmptyMsg = document.getElementById('cart-empty-msg');

    // --- ESTADO DEL CARRITO ---
    let cart = JSON.parse(localStorage.getItem('sodaLimonCart')) || [];

    // --- MANEJO DE EVENTOS ---
    if (openCartBtn) {
        openCartBtn.addEventListener('click', (e) => {
            e.preventDefault();
            cartPanel.classList.add('open');
            cartOverlay.classList.add('open');
        });
    }

    const closeCart = () => {
        cartPanel.classList.remove('open');
        cartOverlay.classList.remove('open');
    };
    if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
    if (cartOverlay) cartOverlay.addEventListener('click', closeCart);

    document.body.addEventListener('click', (e) => {
        if (e.target.classList.contains('add-to-cart-btn')) {
            const card = e.target.closest('.product-card');
            // La línea clave que ahora funcionará gracias al data-id
            const id = card.dataset.id; 
            const name = card.querySelector('h3').textContent;
            const price = parseFloat(card.dataset.precio);
            const image = card.querySelector('.product-img').src;
            addToCart({ id, name, price, image });
        }

        if (e.target.matches('.cart-quantity-controls button')) {
            const cartItem = e.target.closest('.cart-item');
            const id = cartItem.dataset.id;
            const action = e.target.textContent;
            updateQuantity(id, action);
        }

        if (e.target.matches('.cart-remove-btn')) {
            const cartItem = e.target.closest('.cart-item');
            const id = cartItem.dataset.id;
            removeFromCart(id);
        }
    });

    // --- FUNCIONES DEL CARRITO ---
    const addToCart = (product) => {
        const existingItem = cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
        updateCart();
    };

    const updateQuantity = (id, action) => {
        const item = cart.find(item => item.id === id);
        if (!item) return;

        if (action === '+') {
            item.quantity++;
        } else if (action === '-') {
            item.quantity--;
            if (item.quantity <= 0) {
                cart = cart.filter(cartItem => cartItem.id !== id);
            }
        }
        updateCart();
    };

    const removeFromCart = (id) => {
        cart = cart.filter(item => item.id !== id);
        updateCart();
    };

    const saveCartToLocalStorage = () => {
        localStorage.setItem('sodaLimonCart', JSON.stringify(cart));
    };

    const updateCart = () => {
        renderCartItems();
        renderCartTotal();
        saveCartToLocalStorage();
    };

    // --- FUNCIONES DE RENDERIZADO ---
    const renderCartItems = () => {
        if (!cartBody) return;
        cartBody.innerHTML = '';

        if (cart.length === 0) {
            cartBody.appendChild(cartEmptyMsg);
            if(cartEmptyMsg) cartEmptyMsg.style.display = 'block';
            return;
        }

        if(cartEmptyMsg) cartEmptyMsg.style.display = 'none';

        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('cart-item');
            itemElement.dataset.id = item.id;
            itemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}" class="cart-item-img">
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p>S/ ${item.price.toFixed(2)}</p>
                    <div class="cart-quantity-controls">
                        <button>-</button>
                        <span>${item.quantity}</span>
                        <button>+</button>
                    </div>
                </div>
                <button class="cart-remove-btn">🗑️</button>
            `;
            cartBody.appendChild(itemElement);
        });
    };

    const renderCartTotal = () => {
        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        if (cartTotalSpan) cartTotalSpan.textContent = `S/ ${total.toFixed(2)}`;
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        if (cartBadge) {
          cartBadge.textContent = totalItems;
          cartBadge.style.display = totalItems > 0 ? 'flex' : 'none';
        }
    };
    
    // --- INICIALIZACIÓN ---
    updateCart();

    // Ocultar elementos del modal antiguo para evitar conflictos
    const verPedidoBtn = document.querySelector('.ver-pedido');
    if (verPedidoBtn) verPedidoBtn.style.display = 'none';

    const modalAntiguo = document.querySelector('.modal-pedido');
    if (modalAntiguo) modalAntiguo.style.display = 'none';
});