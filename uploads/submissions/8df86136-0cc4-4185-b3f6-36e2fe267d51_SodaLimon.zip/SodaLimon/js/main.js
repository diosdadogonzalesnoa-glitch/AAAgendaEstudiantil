import { initCart } from './modules/cart.js';
import { initFilters } from './modules/filters.js';
import { initAuth } from './modules/auth.js'; 

document.addEventListener('DOMContentLoaded', () => {
    initCart();
    initFilters();
     initAuth(); 

    const productCards = document.querySelectorAll('.product-card');

    productCards.forEach(card => {
        const plusBtn = card.querySelector('.quantity-btn.plus');
        const minusBtn = card.querySelector('.quantity-btn.minus');
        const quantityDisplay = card.querySelector('.quantity-display');
        const addToCartBtn = card.querySelector('.add-to-cart-btn');

        plusBtn.addEventListener('click', () => {
            let quantity = parseInt(quantityDisplay.textContent);
            quantity++;
            quantityDisplay.textContent = quantity;
        });

        minusBtn.addEventListener('click', () => {
            let quantity = parseInt(quantityDisplay.textContent);
            if (quantity > 1) {
                quantity--;
                quantityDisplay.textContent = quantity;
            }
        });

        addToCartBtn.addEventListener('click', () => {
            const quantity = parseInt(quantityDisplay.textContent);
            const product = {
                id: card.dataset.id,
                name: card.querySelector('h3').textContent,
                price: parseFloat(card.dataset.precio),
                image: card.querySelector('.product-img').src,
            };
            
            window.sodaLimon.cart.add(product, quantity);
            window.sodaLimon.cart.open();
        });
    });
});