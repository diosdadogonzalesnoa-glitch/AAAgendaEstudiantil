export function initAuth() {
    const openLoginBtn = document.getElementById('login-btn');
    const closeLoginBtn = document.getElementById('close-login-btn');
    const loginModal = document.getElementById('login-modal');
    const loginOverlay = document.getElementById('login-overlay');
    const loginForm = document.getElementById('login-form');

    const openModal = (e) => {
        if (e) e.preventDefault();
        loginModal.classList.add('open');
        loginOverlay.classList.add('open');
    };

    const closeModal = () => {
        loginModal.classList.remove('open');
        loginOverlay.classList.remove('open');
    };

    if (openLoginBtn) openLoginBtn.addEventListener('click', openModal);
    if (closeLoginBtn) closeLoginBtn.addEventListener('click', closeModal);
    if (loginOverlay) loginOverlay.addEventListener('click', closeModal);

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Por ahora, solo mostraremos una alerta.
            // Aquí es donde se conectaría con un servidor real.
            alert('¡Inicio de sesión simulado! Gracias por probar.');
            closeModal();
        });
    }
}