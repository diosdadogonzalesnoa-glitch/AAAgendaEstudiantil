export function initFilters() {
    const filterInputs = document.querySelectorAll('.filters-sidebar input[type="radio"]');
    // Si no se encuentran filtros en la página, no hagas nada.
    if (filterInputs.length === 0) {
        return; 
    }

    const productCards = document.querySelectorAll('.product-card');
    const productCountSpan = document.getElementById('product-count');

    const filterProducts = () => {
        const selectedCategory = document.querySelector('input[name="categoria"]:checked').value;
        const selectedBrand = document.querySelector('input[name="marca"]:checked').value;
        const selectedPrice = document.querySelector('input[name="precio"]:checked').value;
        let visibleProducts = 0;

        productCards.forEach(card => {
            const cardCategory = card.dataset.categoria;
            const cardBrand = card.dataset.marca;
            const cardPrice = parseFloat(card.dataset.precio);

            const categoryMatch = selectedCategory === 'todas' || cardCategory === selectedCategory;
            const brandMatch = selectedBrand === 'todas' || cardBrand === selectedBrand;
            const priceMatch = selectedPrice === 'all' 
                ? true 
                : (([min, max]) => cardPrice >= min && cardPrice <= max)(selectedPrice.split('-').map(parseFloat));

            if (categoryMatch && brandMatch && priceMatch) {
                card.style.display = 'flex';
                visibleProducts++;
            } else {
                card.style.display = 'none';
            }
        });

        if (productCountSpan) productCountSpan.textContent = `${visibleProducts} Productos`;
    };

    filterInputs.forEach(input => input.addEventListener('change', filterProducts));
    
    // Ejecutar filtro inicial
    filterProducts();
}