export function initCart() {
    const openCartBtn = document.getElementById('open-cart-btn');
    const closeCartBtn = document.getElementById('close-cart-btn');
    const cartPanel = document.getElementById('cart-panel');
    const cartOverlay = document.getElementById('cart-overlay');
    const cartBody = document.getElementById('cart-body');
    const cartTotalSpan = document.getElementById('cart-total');
    const cartBadge = document.getElementById('cart-badge');
    const cartEmptyMsg = document.getElementById('cart-empty-msg');

    let cart = JSON.parse(localStorage.getItem('sodaLimonCart')) || [];

    const openCart = (e) => {
        if (e) e.preventDefault();
        cartPanel.classList.add('open');
        cartOverlay.classList.add('open');
    };

    const closeCart = () => {
        cartPanel.classList.remove('open');
        cartOverlay.classList.remove('open');
    };

    if (openCartBtn) openCartBtn.addEventListener('click', openCart);
    if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
    if (cartOverlay) cartOverlay.addEventListener('click', closeCart);

    const addToCart = (product, quantity) => {
        const existingItem = cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            cart.push({ ...product, quantity });
        }
        updateCart();
    };
    
    const updateQuantity = (id, action) => {
        const item = cart.find(item => item.id === id);
        if (!item) return;
        if (action === '+') item.quantity++;
        else if (action === '-') {
            item.quantity--;
            if (item.quantity <= 0) cart = cart.filter(cartItem => cartItem.id !== id);
        }
        updateCart();
    };

    const removeFromCart = (id) => {
        cart = cart.filter(item => item.id !== id);
        updateCart();
    };
    
    const saveCartToLocalStorage = () => localStorage.setItem('sodaLimonCart', JSON.stringify(cart));

    const renderCartItems = () => {
        if (!cartBody) return;
        cartBody.innerHTML = '';
        if (cart.length === 0) {
            if (cartEmptyMsg) cartBody.appendChild(cartEmptyMsg);
            return;
        }
        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('cart-item');
            itemElement.dataset.id = item.id;
            itemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}" class="cart-item-img">
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p>S/ ${(item.price * item.quantity).toFixed(2)}</p>
                    <div class="cart-quantity-controls"><button>-</button><span>${item.quantity}</span><button>+</button></div>
                </div>
                <button class="cart-remove-btn">🗑️</button>
            `;
            cartBody.appendChild(itemElement);
        });
    };

    const renderCartTotal = () => {
        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        if (cartTotalSpan) cartTotalSpan.textContent = `S/ ${total.toFixed(2)}`;
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        if (cartBadge) {
            cartBadge.textContent = totalItems;
            cartBadge.style.display = totalItems > 0 ? 'flex' : 'none';
        }
    };

    const updateCart = () => {
        renderCartItems();
        renderCartTotal();
        saveCartToLocalStorage();
    };
    const checkoutBtn = document.getElementById('checkout-btn');
if (checkoutBtn) {
    checkoutBtn.addEventListener('click', () => {
        // Si el carrito no está vacío, ir a la página de checkout
        if (cart.length > 0) {
            window.location.href = 'checkout.html';
        } else {
            alert('Tu carrito está vacío.');
        }
    });
}
    window.sodaLimon = { cart: { add: addToCart, open: openCart } };
    
    document.body.addEventListener('click', (e) => {
        if (e.target.closest('.cart-item') && e.target.matches('.cart-quantity-controls button')) {
            updateQuantity(e.target.closest('.cart-item').dataset.id, e.target.textContent);
        }
        if (e.target.matches('.cart-remove-btn, .cart-remove-btn *')) {
            removeFromCart(e.target.closest('.cart-item').dataset.id);
        }
    });

    updateCart();
}