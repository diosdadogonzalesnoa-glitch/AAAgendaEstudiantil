document.addEventListener('DOMContentLoaded', () => {
    const cartItemsContainer = document.getElementById('summary-cart-items');
    const subtotalSpan = document.getElementById('summary-subtotal');
    const shippingSpan = document.getElementById('summary-shipping');
    const totalSpan = document.getElementById('summary-total');
    const checkoutForm = document.getElementById('checkout-form');
    const paymentRadios = document.querySelectorAll('input[name="payment-method"]');
    
    const cart = JSON.parse(localStorage.getItem('sodaLimonCart')) || [];

    if (cart.length === 0 && window.location.pathname.endsWith('checkout.html')) {
        alert("Tu carrito está vacío. Serás redirigido a la página de productos.");
        window.location.href = 'Productos.html';
        return;
    }

    const renderCheckout = () => {
        if (!cartItemsContainer) return;
        cartItemsContainer.innerHTML = '';
        let subtotal = 0;

        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('summary-cart-item');
            itemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}" class="summary-item-img">
                <div class="summary-item-info">
                    <h3>${item.name}</h3>
                    <p>Cantidad: ${item.quantity}</p>
                </div>
                <span class="summary-item-price">S/ ${(item.price * item.quantity).toFixed(2)}</span>
            `;
            cartItemsContainer.appendChild(itemElement);
            subtotal += item.price * item.quantity;
        });

        const shippingCost = 10.00;
        const total = subtotal + shippingCost;

        subtotalSpan.textContent = `S/ ${subtotal.toFixed(2)}`;
        shippingSpan.textContent = `S/ ${shippingCost.toFixed(2)}`;
        totalSpan.textContent = `S/ ${total.toFixed(2)}`;
    };

    // --- LÓGICA PARA MÉTODOS DE PAGO ---
    paymentRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            // 1. Ocultar todos los detalles de pago
            document.querySelectorAll('.payment-details').forEach(detail => detail.style.display = 'none');
            document.querySelectorAll('.payment-option').forEach(option => option.classList.remove('selected'));

            // 2. Mostrar el detalle del método seleccionado
            const selectedMethod = document.querySelector('input[name="payment-method"]:checked').value;
            const detailsId = `${selectedMethod.toLowerCase().split(' ')[0]}-details`; // yape-details, plin-details, etc.
            const detailsElement = document.getElementById(detailsId);
            if (detailsElement) {
                detailsElement.style.display = 'block';
                radio.closest('.payment-option').classList.add('selected');
            }
        });
    });

    checkoutForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Validar que se haya seleccionado un método de pago
        const selectedPayment = document.querySelector('input[name="payment-method"]:checked');
        if (!selectedPayment) {
            alert('Por favor, selecciona un método de pago.');
            return;
        }

        alert(`¡Pedido realizado con éxito usando ${selectedPayment.value}! (Simulación)\nGracias por tu compra.`);
        
        localStorage.removeItem('sodaLimonCart');
        window.location.href = 'index.html';
    });

    renderCheckout();
});